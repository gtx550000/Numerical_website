import React, { useState } from 'react';
import ButtonAppBar from './component/appbar/appbar';
import Home from './component/Home/Home';
import Matrix from './component/Matrix/Matrix'
import Bisection from './component/Bisection/Bisection'
import OnePointIteration from './component/OnePointIteration/onepoint'
import NewtonRaphson from './component/NewtonRaphson/newton'
import TaylorSeries from './component/TaylorSeries/taylor'
import Cramers_Rule from './component/Cramer_Rule/Cramer_Rule';
import Test from './component/test/test';
import { BrowserRouter as Router,Routes,Route } from 'react-router-dom';
function App() {
 
  return (
      <Router>
      <div>
       <ButtonAppBar></ButtonAppBar>
       <Routes>
         <Route>
           <Route path='/Home' element={<Home/>}></Route>
           <Route path='/Bisection'  element={<Bisection/>}></Route>
           <Route path='/Matrix' element={<Matrix/>}></Route>
           <Route path='/OnePointIteration' element={<OnePointIteration/>}></Route>
           <Route path='/NewtonRaphson' element={<NewtonRaphson/>}></Route>
           <Route path='/TaylorSeries' element={<TaylorSeries/>}></Route>
           <Route path='/Cramer_Rule' element={<Cramers_Rule/>}></Route>
           <Route path='/test' element={<Test/>}></Route>
         </Route>
       </Routes>
     </div>
     </Router>
  );
};

export default App
