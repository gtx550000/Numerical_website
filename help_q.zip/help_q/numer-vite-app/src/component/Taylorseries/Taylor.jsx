import React, { useState } from 'react';

const TaylorSeries = () => {
  const [x, setX] = useState(0);
  const [n, setN] = useState(0);
  const [x0, setX0] = useState(0);  // New state for x0
  const [actualValue, setActualValue] = useState(null);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);
  
  const calculateActualValue = (x0) => {
    // Replace this with your actual function
    const actualResult = Math.exp(x0); // Example: calculating e^x
    setActualValue(actualResult);
  };

  const calculateTaylorSeries = (x0) => {  // Modified function to accept x0
    let sum = 0;
    let term = 1;
    for (let i = 0; i <= n; i++) {
      sum += term;
      term *= (x0 - 1) / (i + 1);  // Using x0 instead of x
    }
    setResult(sum);
    
    calculateActualValue(x0);

    // Calculate error
    const absoluteError = Math.abs(actualValue - sum);
    setError(absoluteError);
  };
  

  return (
    <div>
      <h2>calculateTaylorSeries</h2>
      <label>
        x:
        <input
          type="number"
          value={x}
          onChange={(e) => setX(e.target.value)}
        />
      </label>
      <br />
      <label>
        x0 (ค่าเริ่มต้น):
        <input
          type="number"
          value={x0}
          onChange={(e) => setX0(e.target.value)}
        />
      </label>
      <br />
      <label>
        n (จำนวนองค์ประกอบ):
        <input
          type="number"
          value={n}
          onChange={(e) => setN(e.target.value)}
        />
      </label>
      <br />
      <button onClick={() => calculateTaylorSeries(x0)}>คำนวณ</button>
      <br />
      {result !== null && (
        <div>
          <h3>ผลลัพธ์:</h3>
          {result}
        </div>
      )}
      <div>
  {/* ... Your existing JSX ... */}
  {actualValue !== null && (
    <div>
      <h3>Actual Value:</h3>
      {actualValue}
    </div>
  )}
  {error !== null && (
    <div>
      <h3>Error:</h3>
      {error}
    </div>
  )}
</div>

    </div>
    
  );
};

export default TaylorSeries;
