import React, { useState } from 'react';

const CramersRule = () => {
  const [rows, setRows] = useState([]);
  const [columns, setColumns] = useState([]);
  const [result, setResult] = useState('');

  const handleRowChange = (value, index) => {
    const newRows = [...rows];
    newRows[index] = value;
    setRows(newRows);
  }

  const handleColumnChange = (value, index) => {
    const newColumns = [...columns];
    newColumns[index] = value;
    setColumns(newColumns);
  }

  const calculateResult = () => {
    const a = eval(rows.join('+'));
    const b = eval(columns.join('+'));
    const resultValue = b / a;
    setResult(`x = ${resultValue}`);
  }

  return (
    <div>
      {[1, 2, 3].map((index) => (
        <div key={index}>
          <input type="text" onChange={(e) => handleRowChange(e.target.value, index - 1)} />
          <input type="text" onChange={(e) => handleColumnChange(e.target.value, index - 1)} />
        </div>
      ))}
      <button onClick={calculateResult}>Calculate</button>
      <div>{result}</div>
    </div>
  );
}

export default CramersRule;
