import { Mafs, Point, Coordinates,Plot, Theme } from "mafs"
import "mafs/core.css";
import "mafs/font.css";
function HelloFx() {

  return (
    <div className="custommafs">
    <Mafs>
      <Coordinates.Cartesian />
      
    </Mafs>
    
    </div>
    
  )
}
export default HelloFx


