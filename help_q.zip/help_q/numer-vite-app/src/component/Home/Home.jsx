import React,{useState}from "react";
import ReactDOM from "react-dom";

const Home = () =>
{
   const[count,setCount]=useState(0);
   const[total,setTotal]=useState();
   const onClick = () =>
   {
      const newcount = count+1;
      setCount(newcount);
   };

   let onChange = (event) =>
   {
      const newtotal = event.target.value;
      setTotal(newtotal);
      console.log( newtotal);
   };
  return (
     <div>
        <h1>Home</h1>
        <input onChange={onChange}></input>
        <h1>{total}</h1>
        <p>{count}</p>
        <button onClick={onClick}>yss</button>
     </div>
  );
};
export default Home;
